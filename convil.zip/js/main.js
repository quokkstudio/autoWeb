const determineDirection = (event) => {
  const { deltaX, deltaY } = event;
  return Math.abs(deltaX) > Math.abs(deltaY) ? Math.sign(deltaX) : Math.sign(deltaY);
};

document.addEventListener("DOMContentLoaded", () => {
  const docEl = document.documentElement;
  const isLocked = () => docEl.classList.contains("is-scroll-locked") || docEl.classList.contains("is-intro-playing");
  const sections = [...document.querySelectorAll(".page-section")];
  if (!sections.length) return;

  const horizontalSection = document.querySelector("[data-horizontal]");
  const desktopMedia = window.matchMedia("(min-width: 961px)");

  let horizontalController = null;
  let currentSectionIndex = 0;
  let isAnimating = false;
  let scrollTimeoutId = null;

  const goToSection = (targetIndex, originIndex = currentSectionIndex) => {
    if (isLocked()) return; // block programmatic jumps while locked
    if (targetIndex < 0 || targetIndex >= sections.length) return;
    isAnimating = true;
    currentSectionIndex = targetIndex;

    const targetSection = sections[targetIndex];
    if (horizontalController && targetSection === horizontalController.element) {
      if (targetIndex > originIndex) {
        horizontalController.jumpToStart();
      } else if (targetIndex < originIndex) {
        horizontalController.jumpToEnd();
      }
    }

    targetSection.scrollIntoView({ behavior: "smooth", block: "start" });
    window.clearTimeout(scrollTimeoutId);
    scrollTimeoutId = window.setTimeout(() => {
      isAnimating = false;
    }, 900);
  };

  const wheelHandler = (event) => {
    if (isLocked()) { // swallow wheel during intro/lock
      event.preventDefault();
      return;
    }
    if (isAnimating) {
      event.preventDefault();
      return;
    }

    const direction = determineDirection(event);
    if (direction === 0) return;

    const currentSection = sections[currentSectionIndex];
    if (horizontalController && currentSection === horizontalController.element) {
      const result = horizontalController.handle(direction);
      if (result.type === "move") {
        event.preventDefault();
        isAnimating = true;
        window.setTimeout(() => {
          isAnimating = false;
        }, result.duration || horizontalController.duration || 700);
        return;
      }

      if (result.type === "idle") {
        event.preventDefault();
        return;
      }

      if (result.type === "boundary") {
        event.preventDefault();
        const targetIndex = currentSectionIndex + (result.direction > 0 ? 1 : -1);
        goToSection(targetIndex, currentSectionIndex);
        return;
      }
    }

    const targetIndex = currentSectionIndex + direction;
    if (targetIndex >= 0 && targetIndex < sections.length) {
      event.preventDefault();
      goToSection(targetIndex, currentSectionIndex);
    }
  };

  const supportsFinePointer = window.matchMedia("(pointer: fine)").matches;
  let isWheelBound = false;

  const bindWheel = () => {
    if (!supportsFinePointer || isWheelBound) return;
    window.addEventListener("wheel", wheelHandler, { passive: false });
    isWheelBound = true;
  };

  const unbindWheel = () => {
    if (!isWheelBound) return;
    window.removeEventListener("wheel", wheelHandler);
    isWheelBound = false;
  };

  const enableDesktopMode = () => {
    if (horizontalSection && window.createRatioSwiper && !horizontalController) {
      horizontalController = window.createRatioSwiper(horizontalSection);
    }
    bindWheel();
  };

  const disableDesktopMode = () => {
    unbindWheel();
    if (horizontalController) {
      horizontalController.destroy();
      horizontalController = null;
    }
    if (horizontalSection) {
      const track = horizontalSection.querySelector(".horizontal__track");
      if (track) {
        track.style.removeProperty("transform");
      }
    }
  };

  const evaluateMode = () => {
    if (desktopMedia.matches) {
      enableDesktopMode();
    } else {
      disableDesktopMode();
    }
  };

  evaluateMode();

  const navLinks = document.querySelectorAll(".quok-nav a[href^='#']");
  navLinks.forEach((link) => {
    link.addEventListener("click", (event) => {
      event.preventDefault();
      if (isLocked()) return;
      const href = link.getAttribute("href");
      if (!href) return;
      const targetIndex = sections.findIndex((section) => `#${section.id}` === href);
      if (targetIndex !== -1) {
        goToSection(targetIndex);
      }
    });
  });

  let updateTimer;
  window.addEventListener(
    "scroll",
    () => {
      if (isAnimating) return;
      window.clearTimeout(updateTimer);
      updateTimer = window.setTimeout(() => {
        const midpoint = window.scrollY + window.innerHeight / 2;
        let closestIndex = currentSectionIndex;
        let minDistance = Infinity;
        sections.forEach((section, index) => {
          const sectionMid = section.offsetTop + section.offsetHeight / 2;
          const distance = Math.abs(sectionMid - midpoint);
          if (distance < minDistance) {
            minDistance = distance;
            closestIndex = index;
          }
        });
        currentSectionIndex = closestIndex;
      }, 120);
    },
    { passive: true }
  );

  // 이미 상단에 있는 경우 추가 스크롤을 발생시키지 않는다.
  if (window.scrollY > 1) {
    goToSection(0);
  }

  const handleViewportChange = () => {
    evaluateMode();
  };

  if (desktopMedia.addEventListener) {
    desktopMedia.addEventListener("change", handleViewportChange);
  } else if (desktopMedia.addListener) {
    desktopMedia.addListener(handleViewportChange);
  }
});
