(() => {
  const clamp = (value, min, max) => Math.max(min, Math.min(max, value));

  const defaultOptions = {
    trackSelector: ".horizontal__track",
    panelSelector: ".horizontal__panel",
    progressBarSelector: ".horizontal__progress-bar",
    defaultSpan: 1,
    duration: 700,
  };

  const parseSpanValue = (panel, fallback) => {
    const raw = parseFloat(panel.dataset.stepSpan);
    if (Number.isFinite(raw) && raw > 0) return raw;
    if (Number.isFinite(fallback) && fallback > 0) return fallback;
    return 1;
  };

  const applyMegaLayouts = (section) => {
    const megaPanels = section.querySelectorAll(".mega-panel[data-cols]");
    megaPanels.forEach((panel) => {
      const cols = panel.dataset.cols;
      if (!cols) return;
      const values = cols
        .split(/[\s,]+/)
        .map((value) => value.trim())
        .filter(Boolean);
      if (!values.length) return;
      const segments = values
        .map((value) => {
          const hasUnit = /[a-z%]+$/i.test(value);
          const unitValue = hasUnit ? value : `${value}vw`;
          return `minmax(0, ${unitValue})`;
        })
        .join(" ");
      panel.style.setProperty("--mega-grid", segments);
    });
  };

  const buildStops = (stepCounts) => {
    const totalSteps = stepCounts.reduce((sum, step) => sum + step, 0);
    if (totalSteps <= 1) return [0];
    return Array.from({ length: totalSteps }, (_, index) => index);
  };

  const createRatioSwiper = (section, userOptions = {}) => {
    if (!section) return null;
    const options = { ...defaultOptions, ...userOptions };

    const track = section.querySelector(options.trackSelector);
    const panels = Array.from(section.querySelectorAll(options.panelSelector));
    if (!track || !panels.length) return null;

    applyMegaLayouts(section);

    const stepCounts = panels.map((panel) => {
      const span = parseSpanValue(panel, options.defaultSpan);
      const stepCount = Math.max(1, Math.round(span));
      panel.style.setProperty("--panel-span", stepCount);
      return stepCount;
    });

    const stops = buildStops(stepCounts);
    const progressBar = options.progressBarSelector ? section.querySelector(options.progressBarSelector) : null;
    const maxIndex = Math.max(stops.length - 1, 0);

    let stopIndex = 0;
    let position = stops[stopIndex] || 0;
    let isMoving = false;

    const updateProgress = () => {
      if (!progressBar) return;
      if (maxIndex === 0) {
        progressBar.style.width = "100%";
        return;
      }
      const ratio = clamp(stopIndex / maxIndex, 0, 1);
      progressBar.style.width = `${ratio * 100}%`;
    };

    const updateTransform = () => {
      const viewportWidth = window.innerWidth || section.getBoundingClientRect().width;
      track.style.transform = `translateX(-${position * viewportWidth}px)`;
      updateProgress();
    };

    const setStop = (nextIndex, animated = true) => {
      const boundedIndex = Math.max(0, Math.min(maxIndex, nextIndex));
      if (boundedIndex === stopIndex && animated) return false;
      stopIndex = boundedIndex;
      position = stops[stopIndex] || 0;
      if (!animated) {
        isMoving = false;
        updateTransform();
        return true;
      }
      isMoving = true;
      updateTransform();
      window.setTimeout(() => {
        isMoving = false;
      }, options.duration);
      return true;
    };

    const handle = (direction) => {
      if (isMoving || maxIndex === 0) return { type: "idle" };
      const nextIndex = stopIndex + direction;
      if (nextIndex < 0 || nextIndex > maxIndex) {
        return { type: "boundary", direction };
      }
      const moved = setStop(nextIndex);
      if (moved) {
        return { type: "move", duration: options.duration };
      }
      return { type: "boundary", direction };
    };

    const jumpToStart = () => {
      setStop(0, false);
    };

    const jumpToEnd = () => {
      setStop(maxIndex, false);
    };

    const resizeHandler = () => {
      window.requestAnimationFrame(updateTransform);
    };

    window.addEventListener("resize", resizeHandler);
    updateTransform();

    return {
      element: section,
      duration: options.duration,
      handle,
      jumpToStart,
      jumpToEnd,
      goTo: (index, animated = true) => setStop(index, animated),
      destroy: () => {
        window.removeEventListener("resize", resizeHandler);
      },
    };
  };

  window.createRatioSwiper = createRatioSwiper;
  window.RatioSwiper = { createRatioSwiper };
})();
