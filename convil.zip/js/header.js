(() => {
  // 헤더 높이를 CSS 변수로 반영 (고정 헤더 + 메가 시작점 보정)
  const header = document.querySelector('.quok-header');
  const heroSection = document.querySelector('[data-hero]');
  let lastHeight = header ? header.offsetHeight : 0;
  if (header) {
    document.documentElement.style.setProperty('--quok-header-h', `${lastHeight}px`);
  }

  const applyHeight = (next) => {
    if (!header) return;
    if (Math.abs(next - lastHeight) < 0.5) return;
    document.documentElement.style.setProperty('--quok-header-h', `${next}px`);
    lastHeight = next;
  };

  const toggleHeroState = () => {
    if (!header || !heroSection) return;
    const heroRect = heroSection.getBoundingClientRect();
    const headerHeight = header.offsetHeight || 0;
    const shouldHero = heroRect.bottom > headerHeight;
    header.classList.toggle('is-hero', shouldHero);
  };

  if (window.ResizeObserver && header) {
    const observer = new ResizeObserver((entries) => {
      for (const entry of entries) {
        applyHeight(entry.contentRect.height);
        toggleHeroState();
      }
    });
    observer.observe(header);
  } else {
    window.addEventListener('resize', () => {
      if (!header) return;
      window.requestAnimationFrame(() => {
        applyHeight(header.offsetHeight);
        toggleHeroState();
      });
    });
  }

  const isTouch = window.matchMedia && window.matchMedia('(pointer: coarse)').matches;
  const items   = Array.from(document.querySelectorAll('.quok-has-mega'));

  const closeAll = () => items.forEach(i => i.classList.remove('quok-open'));
  const openItem = (i) => { if (!i.classList.contains('quok-open')) { closeAll(); i.classList.add('quok-open'); } };

  // 좌측 선택 → 우측 패널 활성화
  function activatePanel(root, id, btn) {
    if (!root) return;
    const btns   = root.querySelectorAll('.quok-side-btn');
    const panels = root.querySelectorAll('.quok-panel');
    btns.forEach(b => b.classList.toggle('is-active', b === btn));
    panels.forEach(p => p.classList.toggle('is-active', p.id === 'quok-panel-' + id));
  }

  // 데스크탑: hover로 열고 닫기 + hover로 패널 전환
  if (!isTouch) {
    let leaveTimer;
    items.forEach(item => {
      const mega = item.querySelector('.quok-mega');

      item.addEventListener('mouseenter', () => { clearTimeout(leaveTimer); openItem(item); });
      item.addEventListener('mouseleave', () => { leaveTimer = setTimeout(() => item.classList.remove('quok-open'), 90); });

      mega && mega.querySelectorAll('.quok-side-btn').forEach(btn => {
        const id = btn.dataset.quokPanel;
        btn.addEventListener('mouseenter', () => activatePanel(mega, id, btn));
        btn.addEventListener('focus',      () => activatePanel(mega, id, btn));
        btn.setAttribute('aria-controls', 'quok-panel-' + id);
      });
    });

    document.addEventListener('click', e => { if (!e.target.closest('.quok-nav')) closeAll(); });
    document.addEventListener('keydown', e => { if (e.key === 'Escape') closeAll(); });
  } else {
    // 터치: 클릭 토글 + 탭으로 패널 전환
    items.forEach(item => {
      const trig = item.querySelector('.quok-trigger, .quok-link');
      const mega = item.querySelector('.quok-mega');

      trig && trig.addEventListener('click', e => {
        e.preventDefault();
        const nowOpen = item.classList.toggle('quok-open');
        if (nowOpen) items.forEach(x => { if (x !== item) x.classList.remove('quok-open'); });
      });

      mega && mega.querySelectorAll('.quok-side-btn').forEach(btn => {
        const id = btn.dataset.quokPanel;
        btn.addEventListener('click', () => activatePanel(mega, id, btn));
      });
    });

    document.addEventListener('click', e => { if (!e.target.closest('.quok-nav')) closeAll(); });
  }

  // 초기 활성 패널 보정
  document.querySelectorAll('.quok-mega').forEach(mega => {
    const active = mega.querySelector('.quok-side-btn.is-active') || mega.querySelector('.quok-side-btn');
    if (active) activatePanel(mega, active.dataset.quokPanel, active);
  });

  window.addEventListener('scroll', () => {
    toggleHeroState();
  }, { passive: true });
  toggleHeroState();

  /* ===== 모바일 드로어 ===== */
  const mobile  = document.querySelector('.quok-mobile');
  const drawer  = document.querySelector('.quok-drawer');
  const burger  = document.querySelector('.quok-burger');
  const closer  = document.querySelector('.quok-close');
  const svcBtn  = document.querySelector('.quok-mbtn');
  const svcPane = document.querySelector('.quok-mpanel');

  if (burger && mobile) {
    const openDrawer  = () => { mobile.classList.add('is-open'); document.body.style.overflow = 'hidden'; };
    const closeDrawer = () => { mobile.classList.remove('is-open'); document.body.style.overflow = ''; };

    burger.addEventListener('click', openDrawer);
    closer && closer.addEventListener('click', closeDrawer);
    mobile.addEventListener('click', e => { if (!drawer.contains(e.target)) closeDrawer(); });
    svcBtn && svcBtn.addEventListener('click', () => svcPane.classList.toggle('is-open'));

    // 화면 다시 커지면 드로어 닫기
    const mq = window.matchMedia('(max-width: 960px)');
    const sync = () => { if (!mq.matches) closeDrawer(); };
    mq.addEventListener ? mq.addEventListener('change', sync) : mq.addListener(sync);
  }
})();
