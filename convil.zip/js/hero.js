(() => {
  const SLIDE_INTERVAL = 4000; // OWL-like timing

  const hero = document.querySelector("[data-hero]");
  if (!hero) return;

  const slides = Array.from(hero.querySelectorAll(".hero__slide"));
  const bullets = Array.from(hero.querySelectorAll(".hero__bullet"));
  const fills = Array.from(hero.querySelectorAll(".hero__bullet-fill"));
  const labels = Array.from(hero.querySelectorAll(".hero__bullet-label"));
  const titleEl = hero.querySelector(".hero__title");
  const subtitleEl = hero.querySelector(".hero__subtitle");
  const textWrap = hero.querySelector(".hero__text");
  if (!slides.length) return;

  let index = 0;
  let timerId = null;
  let didFirstActivate = false;
  const setBackgrounds = () => {
    slides.forEach((slide) => {
      const image = slide.dataset.image;
      if (image) {
        slide.style.backgroundImage = `url(${image})`;
      }
    });
  };

  const updateLabels = () => {
    labels.forEach((label, i) => {
      const slide = slides[i];
      const bullet = bullets[i];
      if (!slide || !label) return;
      const title = slide.dataset.title || "";
      const order = String(i + 1).padStart(2, "0");
      const text = `${order} ${title}`.trim();
      label.textContent = "";
      const orderSpan = document.createElement("span");
      orderSpan.className = "hero__label-order";
      orderSpan.textContent = order;
      const textSpan = document.createElement("span");
      textSpan.className = "hero__label-text";
      textSpan.textContent = title;
      label.append(orderSpan, textSpan);
      if (bullet) bullet.setAttribute("aria-label", text);
    });
  };

  const resetProgress = () => {
    fills.forEach((fill, i) => {
      if (i !== index) {
        fill.style.transition = "none";
        fill.style.width = "0%";
        // Force reflow to apply width change before re-enabling transition
        void fill.offsetWidth;
        fill.style.transition = "";
      }
    });
  };

  const animateProgress = () => {
    const fill = fills[index];
    if (!fill) return;
    fill.style.transition = "none";
    fill.style.width = "0%";
    void fill.offsetWidth;
    fill.style.transition = `width ${SLIDE_INTERVAL}ms linear`;
    fill.style.width = "100%";
  };

  const activate = (nextIndex) => {
    const total = slides.length;
    const normalized = (nextIndex + total) % total;
    slides.forEach((slide, i) => {
      slide.classList.toggle("is-active", i === normalized);
    });
    bullets.forEach((bullet, i) => {
      bullet.classList.toggle("is-active", i === normalized);
      bullet.setAttribute("aria-pressed", i === normalized ? "true" : "false");
      bullet.setAttribute("aria-current", i === normalized ? "true" : "false");
    });
    index = normalized;
    const activeSlide = slides[index];
    if (activeSlide) {
      if (titleEl) titleEl.textContent = activeSlide.dataset.title || "";
      if (subtitleEl) subtitleEl.textContent = activeSlide.dataset.subtitle || "";
    }
    // Re-trigger text re-enter animation only after the first activation
    if (textWrap && didFirstActivate) {
      textWrap.classList.remove("fx-fade-up");
      void textWrap.offsetWidth; // reflow
      textWrap.classList.add("fx-fade-up");
    }
    resetProgress();
    animateProgress();
    didFirstActivate = true;
  };

  const tick = () => {
    activate(index + 1);
  };

  const start = () => {
    window.clearInterval(timerId);
    timerId = window.setInterval(tick, SLIDE_INTERVAL);
  };

  bullets.forEach((bullet, i) => {
    bullet.addEventListener("click", () => {
      if (i === index) return;
      activate(i);
      start();
    });
  });

  setBackgrounds();
  updateLabels();

  let started = false;
  const begin = () => {
    if (started) return;
    started = true;
    activate(0);
    // Trigger floating re-enter on first view only
    if (textWrap) {
      textWrap.classList.remove("fx-fade-up");
      void textWrap.offsetWidth;
      textWrap.classList.add("fx-fade-up");
    }
    start();
    window.setTimeout(() => {
      document.documentElement.classList.remove("is-scroll-locked");
    }, 100);
  };

  const docEl = document.documentElement;
  if (docEl.classList.contains("is-hero-background")) {
    begin();
  } else {
    const kickoff = () => begin();
    document.addEventListener("hero:background", kickoff, { once: true });
    // Fallback
    document.addEventListener("hero:ready", kickoff, { once: true });
  }
})();
