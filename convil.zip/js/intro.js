(() => {
  const SOURCE_TEXT = "CONNECT VILLIAGE";
  const TARGET_TEXT = "CONVIL";
  const HOLD_BEFORE_MERGE = 420;
  const PER_LETTER_DELAY = 140;
  const MOVE_DURATION = 900;
  const TYPE_DELAY = 95;
  const PICK_SHRINK_TO = 1;
  const NONPICK_SHRINK_TO = 0.45;
  const FAILSAFE_DURATION = 5000;
  const HERO_CONTENT_DELAY = 0;   // show content immediately after intro
  const HERO_BACKGROUND_DELAY = 300; // target ~1s gap to first hero
  const HERO_READY_OFFSET = 2400;

  const docEl = document.documentElement;
  let prefersReducedMotion = false;
  let heroSequenceStarted = false;
  let stageCleared = false;
  let heroReadyMarked = false;

  const stage = document.querySelector("[data-intro-stage]");
  const logo = document.querySelector("[data-logo]");
  if (!stage || !logo) {
    docEl.classList.add("is-hero-content", "is-hero-background", "is-hero-ready");
    docEl.classList.remove("is-scroll-locked");
    heroSequenceStarted = true;
    heroReadyMarked = true;
    document.dispatchEvent(new CustomEvent("hero:background"));
    document.dispatchEvent(new CustomEvent("hero:ready"));
    return;
  }

  const sourceWrap = stage.querySelector("[data-intro-source-wrap]");
  const sourceLettersEl = stage.querySelector("[data-intro-source-letters]");
  const targetWrap = stage.querySelector("[data-intro-target]");
  const targetLettersEl = stage.querySelector("[data-intro-target-letters]");
  const logoLabel = logo.querySelector("[data-logo-label]");
  const logoDisplay = logoLabel || logo;
  docEl.classList.add("is-scroll-locked");

  const markHeroReady = () => {
    if (heroReadyMarked) return;
    heroReadyMarked = true;
    docEl.classList.add("is-hero-ready");
    document.dispatchEvent(new CustomEvent("hero:ready"));
  };

  const kickoffHeroSequence = (options = {}) => {
    if (heroSequenceStarted) return;
    heroSequenceStarted = true;
    if (options.immediate) {
      docEl.classList.add("is-hero-content", "is-hero-background");
      document.dispatchEvent(new CustomEvent("hero:background"));
      markHeroReady();
      return;
    }
    window.setTimeout(() => {
      docEl.classList.add("is-hero-content");
    }, HERO_CONTENT_DELAY);
    window.setTimeout(() => {
      docEl.classList.add("is-hero-background");
      document.dispatchEvent(new CustomEvent("hero:background"));
      window.setTimeout(() => {
        markHeroReady();
      }, HERO_READY_OFFSET);
    }, HERO_CONTENT_DELAY + HERO_BACKGROUND_DELAY);
  };

  const clearStage = () => {
    if (stageCleared) return;
    stageCleared = true;
    docEl.classList.remove("is-intro-playing");
    if (stage) {
      stage.classList.add("is-hidden");
      window.setTimeout(() => {
        if (stage.parentNode) {
          stage.parentNode.removeChild(stage);
        }
      }, 620);
    }
    window.setTimeout(() => {
      kickoffHeroSequence({ immediate: prefersReducedMotion });
    }, 0);
  };

  const setLogoText = (value) => {
    if (!logoDisplay) return;
    logoDisplay.textContent = value;
  };

  if (!sourceWrap || !sourceLettersEl || !targetWrap || !targetLettersEl || !logoDisplay) {
    setLogoText(TARGET_TEXT);
    clearStage();
    return;
  }

  prefersReducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  if (prefersReducedMotion) {
    setLogoText(TARGET_TEXT);
    clearStage();
    return;
  }

  const logoBounds = logoDisplay.getBoundingClientRect();
  const measuredWidth = Math.max(logoBounds.width, 1);
  const measuredHeight = Math.max(logoBounds.height, 1);
  logoDisplay.style.display = "inline-block";
  logoDisplay.style.minWidth = `${measuredWidth}px`;
  logoDisplay.style.minHeight = `${measuredHeight}px`;

  docEl.classList.add("is-intro-playing");
  setLogoText("");

  let finished = false;
  let failsafeTimer = null;
  const finish = () => {
    if (finished) return;
    finished = true;
    if (failsafeTimer) {
      window.clearTimeout(failsafeTimer);
      failsafeTimer = null;
    }
    if (sourceWrap) {
      sourceWrap.style.opacity = "";
    }
    logoDisplay.style.display = "";
    logoDisplay.style.minWidth = "";
    logoDisplay.style.minHeight = "";
    setLogoText(TARGET_TEXT);
    clearStage();
  };

  failsafeTimer = window.setTimeout(finish, FAILSAFE_DURATION);

  const buildLetters = (container, text, animate = false) => {
    container.textContent = "";
    const spans = [];
    for (let i = 0; i < text.length; i += 1) {
      const ch = text[i];
      const el = document.createElement("span");
      el.className = ch === " " ? "intro-space" : "intro-char";
      if (ch === " ") {
        el.innerHTML = "&nbsp;";
      } else {
        el.textContent = ch;
      }
      if (animate) {
        el.style.transformOrigin = "0 0";
        el.style.display = "inline-block";
        el.style.transition = `transform ${MOVE_DURATION}ms cubic-bezier(.2,.8,.2,1), opacity 600ms ease`;
        el.style.willChange = "transform,opacity";
        el.style.transform = "translate3d(0,0,0) scale(1)";
        el.style.opacity = "1";
        el.style.backfaceVisibility = "hidden";
      }
      container.appendChild(el);
      spans.push(el);
    }
    return spans;
  };

  const buildLetterMatchMap = (srcText, tgtText) => {
    const src = srcText.toUpperCase();
    const tgt = tgtText.toUpperCase();
    const map = {};
    const taken = new Set();
    for (let t = 0; t < tgt.length; t += 1) {
      const ch = tgt[t];
      let found = -1;
      for (let i = 0; i < src.length; i += 1) {
        if (src[i] === ch && !taken.has(i)) {
          found = i;
          break;
        }
      }
      if (found !== -1) {
        map[t] = found;
        taken.add(found);
      }
    }
    return map;
  };

  copyLogoStyles();

  const srcSpans = buildLetters(sourceLettersEl, SOURCE_TEXT, false);
  buildLetters(targetLettersEl, TARGET_TEXT, false);
  const tgtSpans = Array.from(targetLettersEl.children);
  const pickMap = buildLetterMatchMap(SOURCE_TEXT, TARGET_TEXT);

  function copyLogoStyles() {
    const style = window.getComputedStyle(logoDisplay);
    const letterGap = style.letterSpacing && style.letterSpacing !== "normal" ? style.letterSpacing : "0.18em";
    const fontFamily = style.fontFamily || '"Playfair Display","Manrope","Noto Sans KR",serif';
    const fontSize = style.fontSize && style.fontSize !== "0px" ? style.fontSize : "48px";
    const fontWeight = style.fontWeight || "600";
    stage.style.setProperty("--intro-letter-gap", letterGap);
    stage.style.setProperty("--intro-font", fontFamily);
    stage.style.setProperty("--intro-font-size", fontSize);
    stage.style.setProperty("--intro-font-weight", fontWeight);
    targetWrap.style.fontFamily = fontFamily;
    targetWrap.style.fontSize = fontSize;
    targetWrap.style.fontWeight = fontWeight;
    targetWrap.style.letterSpacing = letterGap;
  }

  const alignTargetToLogo = () => {
    copyLogoStyles();
    const rect = logoDisplay.getBoundingClientRect();
    targetWrap.style.left = `${rect.left}px`;
    targetWrap.style.top = `${rect.top}px`;
    const letterRect = targetLettersEl.getBoundingClientRect();
    const adjustLeft = rect.left - letterRect.left;
    const adjustTop = rect.bottom - letterRect.bottom - 2;
    const newLeft = rect.left + adjustLeft;
    const newTop = rect.top + adjustTop;
    targetWrap.style.left = `${newLeft}px`;
    targetWrap.style.top = `${newTop}px`;
  };

  const prepareForTypewriter = () => {
    sourceWrap.classList.remove("is-faded");
    targetWrap.classList.remove("is-visible");
    sourceWrap.style.opacity = "1";
    srcSpans.forEach((span) => {
      span.style.transition = "opacity 0.18s ease";
      span.style.transformOrigin = "0 0";
      span.style.transform = "translate3d(0,0,0) scale(1)";
      span.style.opacity = "0";
    });
  };

  const runTypewriter = () => {
    prepareForTypewriter();
    const totalDuration = TYPE_DELAY * srcSpans.length;
    srcSpans.forEach((span, index) => {
      window.setTimeout(() => {
        if (finished) return;
        span.style.opacity = "1";
      }, index * TYPE_DELAY);
    });
    return totalDuration;
  };

  const runMerge = () => {
    if (finished) return;
    srcSpans.forEach((el) => {
      el.style.transition = "none";
      el.style.transform = "translate3d(0,0,0) scale(1)";
      el.style.opacity = "1";
    });
    sourceWrap.classList.remove("is-faded");
    targetWrap.classList.remove("is-visible");
    void stage.offsetWidth;
    alignTargetToLogo();

    requestAnimationFrame(() => {
      requestAnimationFrame(() => {
        if (finished) return;
        const tgtRects = tgtSpans.map((el) => el.getBoundingClientRect());
        const srcRects = srcSpans.map((el) => el.getBoundingClientRect());
        const cornerRect = tgtRects[0];
        const picked = new Set(Object.values(pickMap));
        const pickedCount = Object.keys(pickMap).length;

        let nonPickOrder = 0;
        srcSpans.forEach((el, i) => {
          if (!picked.has(i)) {
            const sRect = srcRects[i];
            const dx = (cornerRect.left - sRect.left) - 6 * nonPickOrder;
            const dy = (cornerRect.top - sRect.top) - 6 * nonPickOrder;
            const delay = (pickedCount + nonPickOrder) * PER_LETTER_DELAY * 0.6;
            el.style.transition = `transform ${MOVE_DURATION}ms cubic-bezier(.2,.8,.2,1) ${delay}ms, opacity 400ms ease ${delay}ms`;
            el.style.transform = `translate3d(${dx}px, ${dy}px, 0) scale(${NONPICK_SHRINK_TO})`;
            el.style.opacity = "0";
            nonPickOrder += 1;
          }
        });

        Object.entries(pickMap).forEach(([tStr, sIdx]) => {
          const tIdx = Number(tStr);
          const sEl = srcSpans[sIdx];
          const tRect = tgtRects[tIdx];
          const sRect = srcRects[sIdx];
          if (!sEl || !tRect || !sRect) return;
          const dx = tRect.left - sRect.left;
          const dy = tRect.top - sRect.top;
          const delay = tIdx * PER_LETTER_DELAY;
          sEl.style.transition = `transform ${MOVE_DURATION}ms cubic-bezier(.2,.8,.2,1) ${delay}ms`;
          sEl.style.transform = `translate3d(${dx}px, ${dy}px, 0) scale(${PICK_SHRINK_TO})`;
          sEl.style.opacity = "1";
        });

        const total = MOVE_DURATION + PER_LETTER_DELAY * (pickedCount + 1);
        window.setTimeout(() => {
          targetWrap.classList.add("is-visible");
          sourceWrap.style.opacity = "";
          sourceWrap.classList.add("is-faded");
          finish();
        }, total + 20);
      });
    });
  };

  const play = () => {
    if (finished) return;
    alignTargetToLogo();
    const typingDuration = runTypewriter();
    window.setTimeout(() => {
      if (finished) return;
      runMerge();
    }, typingDuration + HOLD_BEFORE_MERGE);
  };

  window.addEventListener("load", () => {
    alignTargetToLogo();
    window.setTimeout(play, 140);
  }, { once: true });

  window.addEventListener("resize", () => {
    if (!finished) {
      alignTargetToLogo();
    }
  });

  window.addEventListener("beforeunload", finish);
})();
